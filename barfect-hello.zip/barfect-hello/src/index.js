import React from "react";
import ReactDOM from "react-dom/client";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <div style={{ padding: "50px", textAlign: "center" }}>
    <h1>🎉 HELLO BARFECT!</h1>
    <p>Your website is LIVE!</p>
    <p style={{ color: "#C76B4F", fontWeight: "bold" }}>Now let’s build the real one.</p>
  </div>
);